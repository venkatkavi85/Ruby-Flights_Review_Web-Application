FactoryBot.define do
  factory :user do
    email { "test@example.com" }
    password  { "Password!23" }
  end
end
