## OpenFlights

### A flight reviews app built with Ruby on Rails and React.js

This app is intended to be a example of a CRUD app built with **Ruby on Rails** and **React.js** using **Webpacker**.
